import 'dart:ui';
import 'package:flutter/material.dart';

class MenuListPage extends StatefulWidget {
  const MenuListPage({super.key});

  @override
  State<MenuListPage> createState() => _MenuListPageState();
}

class _MenuListPageState extends State<MenuListPage> {
  String _selectedCategory = 'Semua';
  String _selectedSort = 'Default';
  String _searchQuery = '';

  final TextEditingController _searchController = TextEditingController();
  final PageController _pageController = PageController();
  int _currentBannerIndex = 0;
  
  final Set<int> _favoriteIds = {};
  
  // --- STATE KERANJANG BELANJA AKTIF ---
  final List<Map<String, dynamic>> _cartList = [];

  // Master Data 12 Menu Kantin Bu Sari
  final List<Map<String, dynamic>> _masterMenuList = [
    // --- MAKANAN BERAT (4) ---
    {
      'id': 1,
      'name': 'Ayam Goreng Lalapan',
      'category': 'Makanan Berat',
      'price': 20000,
      'rating': 4.9,
      'image': 'assets/images/Ayam Goreng Lalapan.jpeg',
      'desc': 'Ayam goreng gurih dengan sambal terasi khas Bu Sari dan lalapan segar.',
    },
    {
      'id': 2,
      'name': 'Nasi Uduk Spesial',
      'category': 'Makanan Berat',
      'price': 15000,
      'rating': 4.8,
      'image': 'assets/images/Nasi Uduk.jpeg',
      'desc': 'Nasi uduk harum gurih disajikan dengan tempe orek, telur iris, dan kerupuk.',
    },
    {
      'id': 3,
      'name': 'Ketoprak Telur Dadar',
      'category': 'Makanan Berat',
      'price': 14000,
      'rating': 4.7,
      'image': 'assets/images/ketoprak.jpeg',
      'desc': 'Ketoprak lontong ketupat dengan bumbu kacang kental khas rasa lezat.',
    },
    {
      'id': 4,
      'name': 'Indomie Kuah / Goreng',
      'category': 'Makanan Berat',
      'price': 10000,
      'rating': 4.9,
      'image': 'assets/images/Indomie Kuah atau goreng.jpeg',
      'desc': 'Mie instan favorit racikan spesial lengkap dengan telur dan sayuran.',
    },

    // --- MAKANAN RINGAN (4) ---
    {
      'id': 5,
      'name': 'Dimsum Mentai Spesial',
      'category': 'Makanan Ringan',
      'price': 18000,
      'rating': 4.9,
      'image': 'assets/images/dimsum mentai.jpeg',
      'desc': 'Dimsum olahan daging pilihan ditaburi saus mentai gurih dibakar sempurna.',
    },
    {
      'id': 6,
      'name': 'Pangsit Goreng Krispi',
      'category': 'Makanan Ringan',
      'price': 12000,
      'rating': 4.7,
      'image': 'assets/images/pangsit goreng.jpeg',
      'desc': 'Pangsit goreng renyah isi olahan ayam disajikan dengan cocolan manis pedas.',
    },
    {
      'id': 7,
      'name': 'Bola Keju Nugget Lumer',
      'category': 'Makanan Ringan',
      'price': 12000,
      'rating': 4.8,
      'image': 'assets/images/bola keju nugget.jpeg',
      'desc': 'Cemilan bola keju nugget gurih goreng krispi dengan keju lumer di dalam.',
    },
    {
      'id': 8,
      'name': 'Kentang Goreng Stik',
      'category': 'Makanan Ringan',
      'price': 10000,
      'rating': 4.5,
      'image': 'assets/images/kentang goreng.jpeg',
      'desc': 'Kentang goreng stik krispi bumbu tabur gurih ramah kantong.',
    },

    // --- MINUMAN (4) ---
    {
      'id': 9,
      'name': 'Thai Tea Creamy',
      'category': 'Minuman',
      'price': 8000,
      'rating': 4.8,
      'image': 'assets/images/thai tea.jpeg',
      'desc': 'Minuman olahan teh khas Thailand dikombinasi susu manis segar.',
    },
    {
      'id': 10,
      'name': 'Kopi Hitam / Susu Bu Sari',
      'category': 'Minuman',
      'price': 7000,
      'rating': 4.6,
      'image': 'assets/images/kopi.jpeg',
      'desc': 'Seduhan biji kopi pilihan mantap penambah semangat belajar.',
    },
    {
      'id': 11,
      'name': 'Es Jeruk Peras Segar',
      'category': 'Minuman',
      'price': 6000,
      'rating': 4.7,
      'image': 'assets/images/es jeruk.jpeg',
      'desc': 'Sajikan es jeruk peras buah murni tinggi vitamin C.',
    },
    {
      'id': 12,
      'name': 'Es Teh Manis Melati',
      'category': 'Minuman',
      'price': 4000,
      'rating': 4.9,
      'image': 'assets/images/es teh.jpeg',
      'desc': 'Es teh manis aroma melati segar penawar dahaga terbaik.',
    },
  ];

  @override
  void dispose() {
    _searchController.dispose();
    _pageController.dispose();
    super.dispose();
  }

  // --- FUNGSI TAMBAH KE KERANJANG ---
  void _addToCart(Map<String, dynamic> menu) {
    setState(() {
      final existingIndex = _cartList.indexWhere((item) => item['id'] == menu['id']);
      if (existingIndex >= 0) {
        _cartList[existingIndex]['qty'] = (_cartList[existingIndex]['qty'] ?? 1) + 1;
      } else {
        _cartList.add({
          'id': menu['id'],
          'name': menu['name'],
          'price': menu['price'],
          'image': menu['image'],
          'qty': 1,
        });
      }
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Berhasil menambahkan ${menu['name']} ke keranjang! 🛒'),
        duration: const Duration(seconds: 1),
        backgroundColor: Colors.deepOrange,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  // --- DIALOG KERANJANG BELANJA ---
  void _showCartDialog(BuildContext context) {
    int totalCartPrice = _cartList.fold(0, (sum, item) => sum + ((item['price'] as int) * (item['qty'] as int)));
    int totalQty = _cartList.fold(0, (sum, item) => sum + (item['qty'] as int));
    String menuSummary = _cartList.map((e) => '${e['qty']}x ${e['name']}').join(', ');

    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) {
        return Container(
          padding: const EdgeInsets.all(20),
          height: 400,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.shopping_cart, color: Colors.deepOrange),
                      const SizedBox(width: 8),
                      Text(
                        'Keranjang Belanja (${_cartList.length})',
                        style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context),
                  ),
                ],
              ),
              const Divider(height: 20),
              if (_cartList.isEmpty)
                const Expanded(
                  child: Center(
                    child: Text(
                      'Keranjang masih kosong.\nYuk pilih menu favoritmu di bawah! 🍽️',
                      textAlign: TextAlign.center,
                      style: TextStyle(color: Colors.grey, fontSize: 14),
                    ),
                  ),
                )
              else
                Expanded(
                  child: ListView.builder(
                    itemCount: _cartList.length,
                    itemBuilder: (context, index) {
                      final item = _cartList[index];
                      return ListTile(
                        leading: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: Image.asset(
                            item['image'],
                            width: 50,
                            height: 50,
                            fit: BoxFit.cover,
                          ),
                        ),
                        title: Text(item['name'], style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
                        subtitle: Text('${item['qty']}x - Rp ${item['price']}', style: const TextStyle(fontSize: 12, color: Colors.grey)),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline, color: Colors.red, size: 20),
                          onPressed: () {
                            setState(() {
                              _cartList.removeAt(index);
                            });
                            Navigator.pop(context);
                            _showCartDialog(context); // Refresh dialog
                          },
                        ),
                      );
                    },
                  ),
                ),
              if (_cartList.isNotEmpty) ...[
                const Divider(height: 1),
                const SizedBox(height: 10),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    const Text('Total Belanja:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    Text(
                      'Rp ${totalCartPrice.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}',
                      style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16, color: Colors.deepOrange),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.deepOrange,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 12),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    ),
                    onPressed: () {
                      Navigator.pop(context); // Tutup bottom sheet keranjang
                      
                      // LANGSUNG ARAHKAN KE HALAMAN DETAIL DENGAN DATA KERANJANG GABUNGAN
                      Navigator.pushNamed(
                        context,
                        '/detail',
                        arguments: {
                          'name': menuSummary,
                          'price': totalCartPrice,
                          'image': _cartList.isNotEmpty ? _cartList.first['image'] : 'assets/images/Ayam Goreng Lalapan.jpeg',
                          'category': 'Keranjang Gabungan',
                          'desc': 'Pesanan gabungan dari keranjang belanja (${totalQty} item total).',
                          'rating': 5.0,
                          'isCartBundle': true,
                          'totalQty': totalQty,
                        },
                      );
                    },
                    child: const Text('Lanjut ke Halaman Checkout 🚀', style: TextStyle(fontWeight: FontWeight.bold)),
                  ),
                ),
              ],
            ],
          ),
        );
      },
    );
  }

  // --- DIALOG PROFIL ---
  void _showProfileDialog(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const CircleAvatar(
                radius: 36,
                backgroundColor: Colors.deepOrange,
                child: Icon(Icons.person, size: 40, color: Colors.white),
              ),
              const SizedBox(height: 12),
              const Text(
                'Pelanggan Setia',
                style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              const Text(
                'mahasiswa@university.ac.id',
                style: TextStyle(fontSize: 12, color: Colors.grey),
              ),
              const Divider(height: 24),
              const ListTile(
                leading: Icon(Icons.favorite, color: Colors.red),
                title: Text('Menu Favorit Tersimpan'),
                trailing: Text('Aman', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.green)),
              ),
              const ListTile(
                leading: Icon(Icons.store, color: Colors.deepOrange),
                title: Text('Lokasi Kantin'),
                subtitle: Text('Gedung Kuliah Utama Lt. 1'),
              ),
              const SizedBox(height: 16),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepOrange,
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                  ),
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Tutup'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    List<Map<String, dynamic>> filteredList = _masterMenuList.where((item) {
      bool matchesCategory = true;
      if (_selectedCategory == 'Favorit ❤️') {
        matchesCategory = _favoriteIds.contains(item['id']);
      } else if (_selectedCategory != 'Semua') {
        matchesCategory = item['category'] == _selectedCategory;
      }

      bool matchesSearch = true;
      if (_searchQuery.trim().isNotEmpty) {
        final query = _searchQuery.toLowerCase().trim();
        final name = item['name'].toString().toLowerCase();
        final category = item['category'].toString().toLowerCase();
        final desc = item['desc'].toString().toLowerCase();

        matchesSearch = name.contains(query) || category.contains(query) || desc.contains(query);
      }

      return matchesCategory && matchesSearch;
    }).toList();

    if (_selectedSort == 'Termurah') {
      filteredList.sort((a, b) => (a['price'] as int).compareTo(b['price'] as int));
    } else if (_selectedSort == 'Termahal') {
      filteredList.sort((a, b) => (b['price'] as int).compareTo(a['price'] as int));
    } else if (_selectedSort == 'Rating') {
      filteredList.sort((a, b) => (b['rating'] as double).compareTo(a['rating'] as double));
    }

    int totalCartQty = _cartList.fold(0, (sum, item) => sum + (item['qty'] as int));

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text(''),
        backgroundColor: Colors.deepOrange,
        elevation: 0,
        actions: [
          // --- ICON KERANJANG DENGAN BADGE JUMLAH ITEM ---
          Stack(
            alignment: Alignment.center,
            children: [
              IconButton(
                icon: const Icon(Icons.shopping_cart_outlined, color: Colors.white, size: 26),
                onPressed: () => _showCartDialog(context),
              ),
              if (totalCartQty > 0)
                Positioned(
                  right: 10,
                  top: 10,
                  child: Container(
                    padding: const EdgeInsets.all(4),
                    decoration: const BoxDecoration(
                      color: Colors.amber,
                      shape: BoxShape.circle,
                    ),
                    child: Text(
                      '$totalCartQty',
                      style: const TextStyle(color: Colors.black, fontSize: 9, fontWeight: FontWeight.bold),
                    ),
                  ),
                ),
            ],
          ),

          // --- ICON PROFILE ---
          IconButton(
            icon: const Icon(Icons.account_circle_outlined, color: Colors.white, size: 26),
            onPressed: () => _showProfileDialog(context),
          ),

          const SizedBox(width: 8),
        ],
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20.0),
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.deepOrange, Color(0xFFFF7043)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(24),
                  bottomRight: Radius.circular(24),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // --- TITLE BADGE ---
                  Center(
                    child: Container(
                      width: 280,
                      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 16),
                      decoration: BoxDecoration(
                        gradient: const LinearGradient(
                          colors: [Color(0xFFFFA726), Color(0xFFFF5722)],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(20),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.15),
                            blurRadius: 8,
                            offset: const Offset(0, 4),
                          ),
                        ],
                        border: Border.all(
                          color: Colors.white.withOpacity(0.4),
                          width: 1.2,
                        ),
                      ),
                      child: const Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.storefront, color: Colors.white, size: 20),
                          SizedBox(width: 8),
                          Text(
                            'Kantin Bu Sari',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: Colors.white,
                              letterSpacing: 0.8,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  // --- WIDE IMAGE SLIDER ---
                  SizedBox(
                    height: 140,
                    child: PageView(
                      controller: _pageController,
                      physics: const AlwaysScrollableScrollPhysics(),
                      onPageChanged: (index) {
                        setState(() {
                          _currentBannerIndex = index;
                        });
                      },
                      children: [
                        _buildPromoSlide(
                          imagePath: 'assets/images/Ayam Goreng Lalapan.jpeg',
                          badgeText: '⭐ Menu Andalan',
                          badgeColor: Colors.deepOrange,
                          title: 'Ayam Goreng Lalapan Spesial',
                          subtitle: 'Gurih sambal terasi khas Bu Sari bikin ketagihan!',
                        ),
                        _buildPromoSlide(
                          imagePath: 'assets/images/Nasi Uduk.jpeg',
                          badgeText: '🔥 Favorit Mahasiswa',
                          badgeColor: Colors.amber.shade800,
                          title: 'Nasi Uduk Harum Gurih',
                          subtitle: 'Lengkap dengan tempe orek dan taburan bawang goreng.',
                        ),
                        _buildPromoSlide(
                          imagePath: 'assets/images/thai tea.jpeg',
                          badgeText: '🥤 Promo Segar',
                          badgeColor: Colors.green.shade700,
                          title: 'Thai Tea & Minuman Dingin',
                          subtitle: 'Pereda dahaga terbaik di kala jam istirahat kuliah.',
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 10),

                  // --- DOT INDICATOR SLIDER ---
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: List.generate(3, (index) {
                      return Container(
                        margin: const EdgeInsets.symmetric(horizontal: 4),
                        width: _currentBannerIndex == index ? 20 : 6,
                        height: 6,
                        decoration: BoxDecoration(
                          color: _currentBannerIndex == index ? Colors.white : Colors.white54,
                          borderRadius: BorderRadius.circular(3),
                        ),
                      );
                    }),
                  ),

                  const SizedBox(height: 16),

                  // INPUT SEARCH BAR REAL-TIME
                  Container(
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(14),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.08),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: TextField(
                      controller: _searchController,
                      onChanged: (value) {
                        setState(() {
                          _searchQuery = value;
                        });
                      },
                      decoration: InputDecoration(
                        hintText: 'Cari kata kunci menu (contoh: ayam, teh, dimsum)...',
                        hintStyle: const TextStyle(color: Colors.grey, fontSize: 13),
                        prefixIcon: const Icon(Icons.search, color: Colors.deepOrange, size: 22),
                        suffixIcon: _searchQuery.isNotEmpty
                            ? IconButton(
                                icon: const Icon(Icons.clear, color: Colors.grey, size: 20),
                                onPressed: () {
                                  _searchController.clear();
                                  setState(() {
                                    _searchQuery = '';
                                  });
                                },
                              )
                            : null,
                        border: InputBorder.none,
                        contentPadding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // --- CHIPS KATEGORI ---
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Row(
                children: ['Semua', 'Favorit ❤️', 'Makanan Berat', 'Makanan Ringan', 'Minuman'].map((cat) {
                  final isSelected = _selectedCategory == cat;
                  return Padding(
                    padding: const EdgeInsets.only(right: 8.0),
                    child: ChoiceChip(
                      label: Text(cat),
                      selected: isSelected,
                      selectedColor: cat == 'Favorit ❤️' ? Colors.redAccent : Colors.deepOrange,
                      labelStyle: TextStyle(
                        color: isSelected ? Colors.white : Colors.black87,
                        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      ),
                      onSelected: (selected) {
                        if (selected) {
                          setState(() => _selectedCategory = cat);
                        }
                      },
                    ),
                  );
                }).toList(),
              ),
            ),

            const SizedBox(height: 12),

            // --- DAFTAR TITLE & SORTING DROPDOWN ---
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    _searchQuery.isNotEmpty
                        ? 'Hasil Pencarian (${filteredList.length})'
                        : 'Daftar Menu (${filteredList.length})',
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF2D3142),
                    ),
                  ),
                  Row(
                    children: [
                      const Icon(Icons.sort, size: 18, color: Colors.deepOrange),
                      const SizedBox(width: 4),
                      DropdownButton<String>(
                        value: _selectedSort,
                        underline: const SizedBox(),
                        style: const TextStyle(
                          color: Colors.deepOrange,
                          fontWeight: FontWeight.bold,
                          fontSize: 13,
                        ),
                        items: const [
                          DropdownMenuItem(value: 'Default', child: Text('Urutkan')),
                          DropdownMenuItem(value: 'Termurah', child: Text('Termurah')),
                          DropdownMenuItem(value: 'Termahal', child: Text('Termahal')),
                          DropdownMenuItem(value: 'Rating', child: Text('Rating Highest')),
                        ],
                        onChanged: (val) {
                          if (val != null) {
                            setState(() => _selectedSort = val);
                          }
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 8),

            // --- TAMPILAN JIKA MENU TIDAK DITEMUKAN ---
            if (filteredList.isEmpty)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 50.0),
                child: Center(
                  child: Column(
                    children: [
                      Icon(
                        _searchQuery.isNotEmpty ? Icons.search_off : Icons.favorite_border,
                        size: 64,
                        color: Colors.grey.shade400,
                      ),
                      const SizedBox(height: 12),
                      Text(
                        _searchQuery.isNotEmpty
                            ? 'Menu "$_searchQuery" tidak ditemukan.\nCoba kata kunci lain seperti: ayam, teh, atau goreng.'
                            : _selectedCategory == 'Favorit ❤️'
                                ? 'Belum ada menu favorit.\nKlik ikon ❤️ pada menu yang kamu sukai!'
                                : 'Tidak ada menu di kategori ini.',
                        textAlign: TextAlign.center,
                        style: const TextStyle(color: Colors.grey, fontSize: 14),
                      ),
                    ],
                  ),
                ),
              )
            else
              // --- LIST HASIL PENCARIAN / KATEGORI ---
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: filteredList.length,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                itemBuilder: (context, index) {
                  final menu = filteredList[index];
                  final isFav = _favoriteIds.contains(menu['id']);

                  return Container(
                    margin: const EdgeInsets.only(bottom: 14),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.08),
                          blurRadius: 8,
                          offset: const Offset(0, 3),
                        ),
                      ],
                    ),
                    child: Row(
                      children: [
                        ClipRRect(
                          borderRadius: const BorderRadius.only(
                            topLeft: Radius.circular(16),
                            bottomLeft: Radius.circular(16),
                          ),
                          child: Image.asset(
                            menu['image'],
                            width: 100,
                            height: 100,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) {
                              return Container(
                                width: 100,
                                height: 100,
                                color: Colors.grey.shade200,
                                child: const Icon(Icons.fastfood, color: Colors.deepOrange),
                              );
                            },
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(vertical: 10.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Expanded(
                                      child: Text(
                                        menu['name'],
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: const TextStyle(
                                          fontWeight: FontWeight.bold,
                                          fontSize: 15,
                                        ),
                                      ),
                                    ),
                                    IconButton(
                                      icon: Icon(
                                        isFav ? Icons.favorite : Icons.favorite_border,
                                        color: isFav ? Colors.red : Colors.grey,
                                        size: 20,
                                      ),
                                      onPressed: () {
                                        setState(() {
                                          if (isFav) {
                                            _favoriteIds.remove(menu['id']);
                                          } else {
                                            _favoriteIds.add(menu['id']);
                                          }
                                        });
                                      },
                                    ),
                                  ],
                                ),
                                Row(
                                  children: [
                                    Container(
                                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                                      decoration: BoxDecoration(
                                        color: Colors.deepOrange.shade50,
                                        borderRadius: BorderRadius.circular(6),
                                      ),
                                      child: Text(
                                        menu['category'],
                                        style: TextStyle(
                                          fontSize: 10,
                                          color: Colors.deepOrange.shade800,
                                          fontWeight: FontWeight.bold,
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 8),
                                    const Icon(Icons.star, color: Colors.amber, size: 14),
                                    const SizedBox(width: 2),
                                    Text(
                                      '${menu['rating']}',
                                      style: const TextStyle(fontSize: 11, fontWeight: FontWeight.bold),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 8),
                                Row(
                                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                  children: [
                                    Text(
                                      'Rp ${menu['price'].toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}',
                                      style: const TextStyle(
                                        fontWeight: FontWeight.bold,
                                        fontSize: 14,
                                        color: Colors.deepOrange,
                                      ),
                                    ),
                                    Padding(
                                      padding: const EdgeInsets.only(right: 12.0),
                                      child: Row(
                                        children: [
                                          SizedBox(
                                            height: 32,
                                            width: 32,
                                            child: IconButton(
                                              style: IconButton.styleFrom(
                                                backgroundColor: Colors.green.shade50,
                                                padding: EdgeInsets.zero,
                                              ),
                                              icon: const Icon(Icons.add_shopping_cart, size: 16, color: Colors.green),
                                              onPressed: () => _addToCart(menu),
                                              tooltip: 'Tambah ke Keranjang',
                                            ),
                                          ),
                                          const SizedBox(width: 6),
                                          ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor: Colors.deepOrange,
                                              foregroundColor: Colors.white,
                                              elevation: 0,
                                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.circular(8),
                                              ),
                                            ),
                                            onPressed: () {
                                              Navigator.pushNamed(
                                                context,
                                                '/detail',
                                                arguments: menu,
                                              );
                                            },
                                            child: const Text('Detail', style: TextStyle(fontSize: 11)),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }

  Widget _buildPromoSlide({
    required String imagePath,
    required String badgeText,
    required Color badgeColor,
    required String title,
    required String subtitle,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(16),
        image: DecorationImage(
          image: AssetImage(imagePath),
          fit: BoxFit.cover,
          colorFilter: ColorFilter.mode(
            Colors.black.withOpacity(0.48),
            BlendMode.darken,
          ),
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.15),
            blurRadius: 8,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
            decoration: BoxDecoration(
              color: badgeColor,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              badgeText,
              style: const TextStyle(fontSize: 10, color: Colors.white, fontWeight: FontWeight.bold),
            ),
          ),
          const SizedBox(height: 8),
          Text(
            title,
            style: const TextStyle(
              color: Colors.white,
              fontSize: 17,
              fontWeight: FontWeight.bold,
              shadows: [Shadow(color: Colors.black54, blurRadius: 4, offset: Offset(0, 1))],
            ),
          ),
          const SizedBox(height: 2),
          Text(
            subtitle,
            style: const TextStyle(
              color: Colors.white70,
              fontSize: 12,
              shadows: [Shadow(color: Colors.black54, blurRadius: 4, offset: Offset(0, 1))],
            ),
          ),
        ],
      ),
    );
  }
}