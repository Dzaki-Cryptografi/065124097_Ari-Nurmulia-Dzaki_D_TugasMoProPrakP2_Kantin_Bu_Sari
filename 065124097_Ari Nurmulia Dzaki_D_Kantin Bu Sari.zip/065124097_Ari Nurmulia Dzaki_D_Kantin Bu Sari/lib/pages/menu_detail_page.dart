import 'package:flutter/material.dart';

class MenuDetailPage extends StatefulWidget {
  const MenuDetailPage({super.key});

  @override
  State<MenuDetailPage> createState() => _MenuDetailPageState();
}

class _MenuDetailPageState extends State<MenuDetailPage> {
  int _quantity = 1;
  String _selectedSpicyLevel = 'Sedang';
  String _paymentMethod = 'QRIS';
  final TextEditingController _noteController = TextEditingController();

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  // --- POP-UP DIALOG QRIS YANG AKURAT & INTERAKTIF ---
  void _showQrisPaymentDialog(BuildContext context, String menuName, int totalPrice) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
          title: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Row(
                children: [
                  Icon(Icons.qr_code_2, color: Colors.deepOrange, size: 28),
                  SizedBox(width: 8),
                  Text('Scan QRIS Bu Sari', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                ],
              ),
              IconButton(
                icon: const Icon(Icons.close, size: 20),
                onPressed: () => Navigator.pop(context),
              ),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  'Silakan scan menggunakan m-Banking atau E-Wallet (GoPay, OVO, Dana, ShopeePay)',
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 12, color: Colors.grey),
                ),
                const SizedBox(height: 16),
                
                // Kotak QR Code Akurat (Simulasi QRIS Resmi)
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(16),
                    border: Border.all(color: Colors.deepOrange.shade200, width: 2),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.1),
                        blurRadius: 6,
                        offset: const Offset(0, 3),
                      ),
                    ],
                  ),
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 8),
                        color: Colors.red.shade700,
                        child: const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Text('QRIS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 14)),
                            SizedBox(width: 4),
                            Text('QUICK RESPONSE CODE INDONESIA STANDARD', style: TextStyle(color: Colors.white, fontSize: 6, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Icon(Icons.qr_code, size: 160, color: Colors.black87),
                      const SizedBox(height: 8),
                      const Text('NMID: ID1020304050607', style: TextStyle(fontSize: 10, color: Colors.grey, fontWeight: FontWeight.bold)),
                      const Text('KANTIN BU SARI', style: TextStyle(fontSize: 11, fontWeight: FontWeight.bold, color: Colors.black87)),
                    ],
                  ),
                ),

                const SizedBox(height: 16),

                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: Colors.grey.shade50,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Menu: $menuName (x$_quantity)', style: const TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                      const SizedBox(height: 4),
                      Text('Level Pedas: $_selectedSpicyLevel', style: TextStyle(fontSize: 12, color: Colors.grey.shade700)),
                      const Divider(height: 12),
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          const Text('Total Tagihan:', style: TextStyle(fontSize: 13, fontWeight: FontWeight.bold)),
                          Text(
                            'Rp ${totalPrice.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}',
                            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold, color: Colors.deepOrange),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          actions: [
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.green,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {
                  Navigator.pop(context); // Tutup Dialog QRIS
                  // Lanjut ke halaman sukses / selesai pesan dengan keterangan QRIS yang akurat
                  Navigator.pushNamed(
                    context,
                    '/pesan',
                    arguments: {
                      'menuName': menuName,
                      'quantity': _quantity,
                      'spicyLevel': _selectedSpicyLevel,
                      'note': _noteController.text.trim(),
                      'paymentMethod': 'QRIS / E-Wallet (Lunas)',
                      'totalPrice': totalPrice,
                    },
                  );
                },
                child: const Text('Simulasi Bayar Selesai ✅', style: TextStyle(fontWeight: FontWeight.bold)),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final menuData = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;

    final String menuName = menuData?['name'] ?? 'Menu Spesial Bu Sari';
    final int basePrice = menuData?['price'] ?? 15000;
    final String menuImage = menuData?['image'] ?? 'assets/images/Ayam Goreng Lalapan.jpeg';
    final String menuDesc = menuData?['desc'] ?? 'Hidangan lezat racikan spesial Kantin Bu Sari.';

    int totalPrice = basePrice * _quantity;

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text(
          'Detail & Opsi Pesanan',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: Colors.deepOrange,
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(24.0),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(24),
                  bottomRight: Radius.circular(24),
                ),
              ),
              child: Column(
                children: [
                  ClipRRect(
                    borderRadius: BorderRadius.circular(18),
                    child: Image.asset(
                      menuImage,
                      width: 140,
                      height: 140,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return Container(
                          width: 140,
                          height: 140,
                          color: Colors.deepOrange.shade50,
                          child: const Icon(Icons.fastfood, color: Colors.deepOrange, size: 60),
                        );
                      },
                    ),
                  ),
                  const SizedBox(height: 16),
                  Text(
                    menuName,
                    textAlign: TextAlign.center,
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF2D3142),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    'Rp ${basePrice.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}',
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: Colors.deepOrange,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    menuDesc,
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 13, color: Colors.grey),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildSectionCard(
                    title: 'Jumlah Porsi',
                    icon: Icons.format_list_numbered,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Pilih Porsi',
                          style: TextStyle(fontWeight: FontWeight.w600, fontSize: 15),
                        ),
                        Container(
                          decoration: BoxDecoration(
                            color: Colors.grey.shade100,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            children: [
                              IconButton(
                                icon: const Icon(Icons.remove, color: Colors.deepOrange),
                                onPressed: () {
                                  if (_quantity > 1) {
                                    setState(() => _quantity--);
                                  }
                                },
                              ),
                              Text(
                                '$_quantity',
                                style: const TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.add, color: Colors.deepOrange),
                                onPressed: () {
                                  setState(() => _quantity++);
                                },
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 16),

                  _buildSectionCard(
                    title: 'Request Makanan (Tingkat Kepedasan)',
                    icon: Icons.local_fire_department,
                    child: Wrap(
                      spacing: 8.0,
                      children: ['Tidak Pedas', 'Sedang', 'Pedas Banget'].map((level) {
                        final isSelected = _selectedSpicyLevel == level;
                        return ChoiceChip(
                          label: Text(level),
                          selected: isSelected,
                          selectedColor: Colors.deepOrange,
                          labelStyle: TextStyle(
                            color: isSelected ? Colors.white : Colors.black87,
                            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                          ),
                          onSelected: (bool selected) {
                            if (selected) {
                              setState(() => _selectedSpicyLevel = level);
                            }
                          },
                        );
                      }).toList(),
                    ),
                  ),

                  const SizedBox(height: 16),

                  _buildSectionCard(
                    title: 'Catatan Tambahan untuk Kasir/Dapur',
                    icon: Icons.edit_note,
                    child: TextField(
                      controller: _noteController,
                      decoration: InputDecoration(
                        hintText: 'Contoh: Jangan pakai daun bawang, kerupuk dipisah...',
                        hintStyle: TextStyle(fontSize: 13, color: Colors.grey.shade400),
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: BorderSide(color: Colors.grey.shade300),
                        ),
                        focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                          borderSide: const BorderSide(color: Colors.deepOrange),
                        ),
                        contentPadding: const EdgeInsets.all(12),
                      ),
                    ),
                  ),

                  const SizedBox(height: 16),

                  _buildSectionCard(
                    title: 'Metode Pembayaran',
                    icon: Icons.payment,
                    child: Column(
                      children: [
                        _buildPaymentOption(
                          title: 'QRIS / E-Wallet (GoPay/OVO/Dana)',
                          subtitle: 'Scan langsung saat pesanan diantar/diambil',
                          value: 'QRIS',
                          icon: Icons.qr_code_scanner,
                        ),
                        const Divider(height: 1),
                        _buildPaymentOption(
                          title: 'Tunai / Cash di Kasir',
                          subtitle: 'Bayar langsung di counter Kantin Bu Sari',
                          value: 'Cash',
                          icon: Icons.payments_outlined,
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      borderRadius: BorderRadius.circular(16),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.05),
                          blurRadius: 10,
                          offset: const Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            const Text(
                              'Total Biaya',
                              style: TextStyle(fontSize: 12, color: Colors.grey),
                            ),
                            Text(
                              'Rp ${totalPrice.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}',
                              style: const TextStyle(
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                color: Colors.deepOrange,
                              ),
                            ),
                          ],
                        ),
                        ElevatedButton.icon(
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.deepOrange,
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                          ),
                          onPressed: () {
                            if (_paymentMethod == 'QRIS') {
                              _showQrisPaymentDialog(context, menuName, totalPrice);
                            } else {
                              Navigator.pushNamed(
                                context,
                                '/pesan',
                                arguments: {
                                  'menuName': menuName,
                                  'quantity': _quantity,
                                  'spicyLevel': _selectedSpicyLevel,
                                  'note': _noteController.text.trim(),
                                  'paymentMethod': 'Tunai / Cash',
                                  'totalPrice': totalPrice,
                                },
                              );
                            }
                          },
                          icon: const Icon(Icons.shopping_cart_checkout),
                          label: const Text(
                            'Pesan Sekarang',
                            style: TextStyle(fontWeight: FontWeight.bold),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 30),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildSectionCard({required String title, required IconData icon, required Widget child}) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.06),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, size: 20, color: Colors.deepOrange),
              const SizedBox(width: 8),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 15,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF2D3142),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          child,
        ],
      ),
    );
  }

  Widget _buildPaymentOption({
    required String title,
    required String subtitle,
    required String value,
    required IconData icon,
  }) {
    return RadioListTile<String>(
      value: value,
      groupValue: _paymentMethod,
      activeColor: Colors.deepOrange,
      contentPadding: EdgeInsets.zero,
      title: Text(
        title,
        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14),
      ),
      subtitle: Text(
        subtitle,
        style: const TextStyle(fontSize: 12, color: Colors.grey),
      ),
      secondary: Icon(icon, color: Colors.deepOrange),
      onChanged: (String? val) {
        if (val != null) {
          setState(() => _paymentMethod = val);
        }
      },
    );
  }
}