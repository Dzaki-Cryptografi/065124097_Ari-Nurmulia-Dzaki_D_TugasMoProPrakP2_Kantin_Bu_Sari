import 'package:flutter/material.dart';

class OrderPage extends StatelessWidget {
  const OrderPage({super.key});

  @override
  Widget build(BuildContext context) {
    // Menangkap argumen yang dikirim dari halaman detail atau keranjang
    final args = ModalRoute.of(context)?.settings.arguments as Map<String, dynamic>?;

    final String menuName = args?['menuName'] ?? 'Paket Menu Kantin Bu Sari';
    final int quantity = args?['quantity'] ?? 1;
    final String spicyLevel = args?['spicyLevel'] ?? 'Sedang';
    final String note = args?['note'] ?? '-';
    final String paymentMethod = args?['paymentMethod'] ?? 'Tunai / Cash';
    final int totalPrice = args?['totalPrice'] ?? 20000;

    // Cek apakah metode pembayaran mengandung kata QRIS atau E-Wallet
    final bool isQRIS = paymentMethod.toLowerCase().contains('qris') || 
                        paymentMethod.toLowerCase().contains('wallet') || 
                        paymentMethod.toLowerCase().contains('lunas');

    return Scaffold(
      backgroundColor: const Color(0xFFF8F9FA),
      appBar: AppBar(
        title: const Text(
          'Struk Pesanan Digital',
          style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white),
        ),
        backgroundColor: Colors.deepOrange,
        iconTheme: const IconThemeData(color: Colors.white),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          children: [
            // --- KARTU STATUS PEMBAYARAN ---
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                children: [
                  Container(
                    width: 70,
                    height: 70,
                    decoration: BoxDecoration(
                      color: isQRIS ? Colors.green.shade50 : Colors.amber.shade50,
                      shape: BoxShape.circle,
                    ),
                    child: Icon(
                      isQRIS ? Icons.check_circle : Icons.point_of_sale,
                      color: isQRIS ? Colors.green : Colors.deepOrange,
                      size: 36,
                    ),
                  ),
                  const SizedBox(height: 14),
                  Text(
                    isQRIS ? 'Pembayaran QRIS Berhasil (Lunas)' : 'Bayar di Kasir Bu Sari',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: isQRIS ? Colors.green.shade700 : const Color(0xFF2D3142),
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    isQRIS 
                        ? 'Transaksi telah diverifikasi secara digital.' 
                        : 'Tunjukkan nomor antrean ini kepada kasir untuk menyelesaikan pembayaran.',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontSize: 12, color: Colors.grey),
                  ),
                  const SizedBox(height: 16),
                  Container(
                    width: double.infinity,
                    padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 16),
                    decoration: BoxDecoration(
                      color: isQRIS ? Colors.green.shade600 : Colors.deepOrange,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      isQRIS ? '✅ LUNAS - SILAHKAN AMBIL PESANAN' : '⚠️ BELUM DIBAYAR - BAYAR DI KASIR',
                      textAlign: TextAlign.center,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // --- INSTRUKSI PEMBAYARAN ---
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: isQRIS ? Colors.green.shade50 : Colors.orange.shade50,
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: isQRIS ? Colors.green.shade200 : Colors.orange.shade200,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(
                        isQRIS ? Icons.verified : Icons.info_outline,
                        color: isQRIS ? Colors.green.shade800 : Colors.deepOrange,
                        size: 20,
                      ),
                      const SizedBox(width: 8),
                      Text(
                        isQRIS ? 'Informasi Status Pesanan:' : 'Instruksi Pembayaran Kasir:',
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          color: isQRIS ? Colors.green.shade800 : Colors.deepOrange.shade800,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    isQRIS 
                        ? '1. Pembayaran via QRIS telah diterima.\n2. Tunjukkan halaman struk ini ke dapur/kasir Kantin Bu Sari.\n3. Tunggu sebentar hingga pesananmu siap disajikan.'
                        : '1. Datang ke Kasir Kantin Bu Sari.\n2. Sebutkan Kode Antrean di bawah.\n3. Bayar sejumlah total tagihan secara tunai.',
                    style: const TextStyle(fontSize: 12, height: 1.5, color: Colors.black87),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // --- RINCIAN STRUK ---
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.04),
                    blurRadius: 10,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(
                        'KANTIN BU SARI',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15, letterSpacing: 0.8),
                      ),
                      Icon(Icons.receipt_long, color: Colors.deepOrange),
                    ],
                  ),
                  const Divider(height: 24),
                  _buildReceiptRow('No. Antrean / ID', 'KBS-142409'),
                  const SizedBox(height: 8),
                  _buildReceiptRow('Tanggal', '15 Okt 2026, 20:33 WIB'),
                  const SizedBox(height: 8),
                  _buildReceiptRow('Metode Bayar', paymentMethod),
                  const Divider(height: 24),
                  const Text('Rincian Pesanan:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 13)),
                  const SizedBox(height: 10),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('$quantity${'x'} $menuName', style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
                            const SizedBox(height: 2),
                            Text('Level Pedas: $spicyLevel', style: const TextStyle(fontSize: 11, color: Colors.grey)),
                            if (note.isNotEmpty && note != '-')
                              Text('Catatan: $note', style: const TextStyle(fontSize: 11, color: Colors.grey)),
                          ],
                        ),
                      ),
                      Text(
                        'Rp ${totalPrice.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}',
                        style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 13),
                      ),
                    ],
                  ),
                  const Divider(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text(
                        'Total Pembayaran',
                        style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15),
                      ),
                      Text(
                        'Rp ${totalPrice.toString().replaceAllMapped(RegExp(r'(\d{1,3})(?=(\d{3})+(?!\d))'), (Match m) => '${m[1]}.')}',
                        style: const TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                          color: Colors.deepOrange,
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 30),

            // --- TOMBOL KEMBALI KE MENU ---
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.deepOrange,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                ),
                onPressed: () {
                  Navigator.pushNamedAndRemoveUntil(context, '/', (route) => false);
                },
                child: const Text('Kembali ke Menu Utama', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildReceiptRow(String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12)),
        Text(value, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 12)),
      ],
    );
  }
}